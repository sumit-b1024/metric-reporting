<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            
        </div>
    </div>
</footer><?php /**PATH C:\xampp82\htdocs\KamranPajiProject\resources\views/layouts/footer.blade.php ENDPATH**/ ?>