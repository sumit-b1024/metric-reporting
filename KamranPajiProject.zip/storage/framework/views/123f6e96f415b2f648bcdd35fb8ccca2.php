
<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="py-3 mb-2">Roles List</h4>
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
        </button>
    </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
        </button>
    </div>
    <?php endif; ?>
    <p>A role provided access to predefined menus and features so that depending on <br> assigned role an administrator can have access to what user needs.</p>
    <!-- Role cards -->
    <div class="row g-4">
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-4 col-lg-6 col-md-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <h6 class="fw-normal">Total 4 users</h6>
                        <ul class="list-unstyled d-flex align-items-center avatar-group mb-0">
                            <li data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Vinnie Mostowy" class="avatar avatar-sm pull-up">
                                <img class="rounded-circle" src="<?php echo e(asset('assets/img/avatars/5.png')); ?>" alt="Avatar">
                            </li>
                            <li data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Allen Rieske" class="avatar avatar-sm pull-up">
                                <img class="rounded-circle" src="<?php echo e(asset('assets/img/avatars/12.png')); ?>" alt="Avatar">
                            </li>
                            <li data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Julee Rossignol" class="avatar avatar-sm pull-up">
                                <img class="rounded-circle" src="<?php echo e(asset('assets/img/avatars/6.png')); ?>" alt="Avatar">
                            </li>
                            <li data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Kaith D'souza" class="avatar avatar-sm pull-up">
                                <img class="rounded-circle" src="<?php echo e(asset('assets/img/avatars/15.png')); ?>" alt="Avatar">
                            </li>
                            <li data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="John Doe" class="avatar avatar-sm pull-up">
                                <img class="rounded-circle" src="<?php echo e(asset('assets/img/avatars/1.png')); ?>" alt="Avatar">
                            </li>
                        </ul>
                    </div>
                    
                    <div class="d-flex justify-content-between align-items-end">
                        <div class="role-heading">
                            <h4 class="mb-1"><?php echo e($role->name); ?></h4>
                            <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#addRoleModal" class="role-edit-modal editButton" data-id=<?php echo e($role->id); ?>><small>Edit Role</small></a>
                        </div>
                        <a href="javascript:void(0);" class="text-muted delete-record" data-id=<?php echo e($role->id); ?> data-bs-toggle="modal" data-route=<?php echo e(route('roles.destroy', $role->id)); ?> data-bs-target="#toggleModal" data-content="Are you sure you want to delete this Role?"><i class="fa-solid fa-trash"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-4 col-lg-6 col-md-6">
            <div class="card h-100">
                <div class="row h-100">
                    <div class="col-sm-5">
                        <div class="d-flex align-items-end h-100 justify-content-center mt-sm-0 mt-3">
                            <img src="<?php echo e(asset('assets/img/illustrations/sitting-girl-with-laptop-light.png')); ?>" class="img-fluid" alt="Image" width="120">
                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="card-body text-sm-end text-center ps-sm-0">
                            <button data-bs-target="#addRoleModal" data-bs-toggle="modal" class="btn btn-primary mb-3 text-nowrap add-new-role">Add New Role</button>
                            <p class="mb-0">Add role, if it does not exist</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12">
            <!-- Role Table -->
            <div class="card">
                <div class="card-datatable table-responsive">
                    <table class="datatables-users table border-top">
                        <thead>
                            <tr>
                                <th>Role</th>
                                <th>No of Users</th>
                                <th>Created_At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><span class="text-nowrap"><?php echo e($role->name); ?></span></td>
                            <td>4 Users</td>
                            <td><span class="text-nowrap"><?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $role->created_at)->format('d M Y, g:i A')); ?></span></td>
                            <td>
                                <span class="text-nowrap">
                                    <button class="btn btn-sm btn-icon me-2 editButton" data-bs-target="#editPermissionModal" data-bs-toggle="modal" data-bs-dismiss="modal" data-id=<?php echo e($role->id); ?>><i class="bx bx-edit"></i></button>
                                    <button class="btn btn-sm btn-icon delete-record" data-id=<?php echo e($role->id); ?> data-bs-toggle="modal" data-route=<?php echo e(route('roles.destroy', $role->id)); ?> data-bs-target="#toggleModal" data-content="Are you sure you want to delete this Role?"><i class="bx bx-trash"></i></button>
                                </span></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
            <!--/ Role Table -->
        </div>
    </div>
    <!--/ Role cards -->
    <!-- Add Role Modal -->
    <!-- Add Role Modal -->
    <div class="modal fade" id="addRoleModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-simple modal-dialog-centered modal-add-new-role">
            <div class="modal-content p-3 p-md-5">
                <div class="modal-body">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <div class="text-center mb-4">
                        <h3 class="role-title">Add New Role</h3>
                        <p>Set role permissions</p>
                    </div>
                    <!-- Add role form -->
                    <div id="message"></div>
                    <form id="addRoleForm" class="row g-3" action="<?php echo e(route('roles.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="" id="edit-id">
                        <div class="col-12 mb-4">
                            <label class="form-label" for="name">Role Name</label>
                            <input type="text" id="name" name="name" class="form-control" placeholder="Enter a role name" tabindex="-1" />
                            <div id="nameError" class="text-danger"></div>
                        </div>
                        <div class="col-12">
                            <h4>Role Permissions</h4>
                            <!-- Permission table -->
                            <div class="table-responsive">
                                <table class="table table-flush-spacing">
                                    <tbody>
                                        <tr>
                                            <td class="text-nowrap fw-medium">Super Admin Access <i class="bx bx-info-circle bx-xs" data-bs-toggle="tooltip" data-bs-placement="top" title="Allows a full access to the system"></i></td>
                                            <td>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="selectAll" />
                                                    <label class="form-check-label" for="selectAll">
                                                    Select All
                                                    </label>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php $__currentLoopData = $permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                        <tr>
                                            <td class="text-nowrap fw-medium"><?php echo e($permission_group->name); ?></td>
                                            <td>
                                                <div class="d-flex">
                                                    <?php $__currentLoopData = $permission_group->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="form-check me-3 me-lg-5">
                                                        <input class="form-check-input" type="checkbox" id="<?php echo e($permission->name); ?>" value="<?php echo e($permission->name); ?>" name="permission[]"/>
                                                        <label class="form-check-label" for="<?php echo e($permission->name); ?>">
                                                            <?php echo e(ucwords(substr($permission->name, strpos($permission->name, "-") + 1))); ?>

                                                        </label>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- Permission table -->
                        </div>
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-primary me-sm-3 me-1">Submit</button>
                            <button type="reset" class="btn btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">Cancel</button>
                        </div>
                    </form>
                    <!--/ Add role form -->
                </div>
            </div>
        </div>
    </div>
    <!--/ Add Role Modal -->
    <!-- / Add Role Modal -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/js/app-access-roles.js')); ?>"></script>
<script>
    const selectAllCheckbox = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('[type="checkbox"]');
    
    selectAllCheckbox.addEventListener('change', () => {
        checkboxes.forEach(checkbox => checkbox.checked = selectAllCheckbox.checked);
    });
    
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            selectAllCheckbox.checked = [...checkboxes].every(cb => cb.checked);
        });
    });
    $(document).on('click', '.editButton', function() {
        openEditModalWithFetch($(this).attr('data-id'));
    });
    $(document).ready(function() {
        $('#addRoleForm').submit(function(event) {
            if($('#edit-id').val() !== '') {
                var route = '/roles/' + $('#edit-id').val();
                var method = 'PUT';
            } else {
                var route = $(this).attr('action');
                var method = 'POST';
            }
            event.preventDefault(); // Prevent default form submission

            $.ajax({
                url: route,
                type: method,
                data: $(this).serialize(),
                success: function(response) {
                    // Clear previous error messages
                    $('#nameError').html('');

                    // Check if validation errors exist
                    if (response.errors) {
                        if (response.errors.name) {
                            $('#nameError').html(response.errors.name[0]);
                        }
                    } else {
                        if (response.success){
                            $('#message').html('<div class="alert alert-success" role="alert">' + response.success + '</div>');
                        } else {
                            $('#message').html('<div class="alert alert-danger" role="alert">' + response.error + '</div>');
                        }
                        setTimeout(function() {location.reload();}, 2000);
                    }
                },
                error: function(xhr) {
                    // Handle AJAX errors if any
                    response = JSON.parse(xhr.responseText);
                    if (response.errors.name) {
                        $('#nameError').html(response.errors.name[0]);
                    } else {
                        if (response.success){
                            $('#message').html('<div class="alert alert-success" role="alert">' + response.success + '</div>');
                        } else {
                            $('#message').html('<div class="alert alert-danger" role="alert">' + response.error + '</div>');
                        }
                    }
                }
            });
        });
    });
    function openEditModalWithFetch(roleId) {
        $.ajax({
            url: '/roles/' + roleId,
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.status == 'success') {
                    var roleData = JSON.parse(response.data.role);
                    var rolePermission = JSON.parse(response.data.rolePermissions);
                    $('#edit-id').val(roleId);
                    $('#name').val(roleData.name);
                    $('input[name="permission[]"]').prop('checked', false); // Uncheck all checkboxes first
                    $.each(rolePermission, function(index, value) {
                        $('#' + value.name).prop('checked', true);
                    });
                    $('#addRoleForm').attr('class', 'editRoleForm');
                    $('#addRoleModal').modal('show');
                } else {
                    console.error('Failed to fetch permission data');
                }
            },
            error: function(xhr) {
                // Handle AJAX error
                console.error('Error fetching permission data:', xhr.responseText);
            }
        });
    }
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Rednirus_cms\resources\views/roles/index.blade.php ENDPATH**/ ?>