<?php $__env->startSection('content'); ?>
<div class="container-xxl mt-4 flex-grow-1 container-p-y">
    <h4 class="py-3 mb-2">Permissions List</h4>
    
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <p class="mb-4">Each category (Basic, Professional, and Business) includes the four predefined roles shown below.</p>

    <!-- Permission Table -->
    <div class="card">
        <div class="card-datatable table-responsive">
            <table class="datatables-permissions table border-top">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th class="sorting_disabled">Operation</th>
                        <th class="sorting_disabled">Created Date</th>
                        <th class="sorting_disabled">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $colors = [
                            'list'      => 'info',
                            'create'    => 'primary',
                            'edit'      => 'success',
                            'delete'    => 'danger'
                        ];
                    ?>
                    
                    <?php $__currentLoopData = $permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><span class="text-nowrap"><?php echo e($permission_group->name); ?></span></td>
                        <td>
                            <span class="text-nowrap">
                                <?php $__currentLoopData = $permission_group->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge bg-label-<?php echo e($colors[substr($permission->name, strpos($permission->name, "-") + 1)]); ?> m-1">
                                        <?php echo e(substr($permission->name, strpos($permission->name, "-") + 1)); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </span>
                        </td>
                        <td><span class="text-nowrap"><?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $permission_group->created_at)->format('d M Y, g:i A')); ?></span></td>
                        <td>
                            <span class="text-nowrap">
                                <button class="btn btn-sm btn-icon me-2 editButton" data-id="<?php echo e($permission_group->id); ?>">
                                    <i class="fa fa-pen"></i>
                                </button>
                                <button class="btn btn-sm btn-icon delete-record" data-id="<?php echo e($permission_group->id); ?>" data-route="<?php echo e(route('permissions.destroy', $permission_group->id)); ?>">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\KamranPajiProject\resources\views/permissions/index.blade.php ENDPATH**/ ?>