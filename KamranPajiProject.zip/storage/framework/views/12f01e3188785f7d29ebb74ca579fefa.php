<?php $__env->startSection('content'); ?>
<div class="container-xxl mt-4 flex-grow-1 container-p-y">
    <div class="row g-4 mb-4">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
    </div>


    <!-- Datatable Card -->
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">Airport SIDA Badges List</h5>
            <a href="<?php echo e(route('airport-badge.create')); ?>" class="btn btn-success float-right">+ Add Airport SIDA Badge</a>
            <button type="button" class="btn btn-success float-right mr-1" data-bs-toggle="modal" data-bs-target="#bulkImportModal">
                Bulk Airport SIDA Badges
            </button>
        </div>
        <div class="card-body">
            <?php echo $dataTable->table(['class' => 'table table-responsive']); ?>

        </div>
    </div>
    <!-- Bulk Import Modal -->
    <div class="modal fade" id="bulkImportModal" tabindex="-1" aria-labelledby="bulkImportModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="bulkImportModalLabel">Bulk Import Airport Badges</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('airport_badge.import')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="file" class="form-label">Choose CSV File</label>
                            <input type="file" name="file" class="form-control" required accept=".csv">
                            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <!-- Validation Points -->
                            <small class="form-text text-muted mt-2">
                                <strong>Instructions for File Upload:</strong>
                                <ul>
                                    <li>The file must be in <strong>CSV</strong> format.</li>
                                    <li>Maximum file size allowed: <strong>2MB</strong>.</li>
                                    <li>The CSV file should include the following columns: <code>employee_id, security_front_id, security_back_id, privilege, expire_date, renew_date, front_image, back_image</code>.</li>
                                    <li><strong>employee_id</strong> should correspond to an existing employee's ID in the database.</li>
                                    <li><strong>expire_date</strong> and <strong>renew_date</strong> must be in the <strong>YYYY-MM-DD</strong> format.</li>
                                    <li>The <strong>front_image</strong> and <strong>back_image</strong> columns should contain the filenames of images that should exist on the server.</li>
                                </ul>
                            </small>

                            <!-- Link to Download Sample CSV -->
                            <div class="mt-3">
                                <a href="<?php echo e(asset('sample_airport_badge.csv')); ?>" class="btn btn-link">Download Sample CSV</a>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">Import</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\KamranPajiProject\resources\views/airport-badges/index.blade.php ENDPATH**/ ?>